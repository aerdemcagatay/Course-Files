/*
	Ahmet Erdem Cagatay - 49826
	COMP410 - Assignment #1
*/
/*
	Unfortunately, I could't healthily draw the sphere object. It doesn't get positioned to the left-top and its color isn't adjusted. 
	However, this code does the basics of the requirements correctly:
	-It draws a cube object and makes it bounce on the ground with a decreasing velocity.
	-It fixes model view and projection for well display. Also, it handles reshaping without ruining display.
	-It creates menu options for shape, drawing mode, and color.
	-Selecting those options changes the shape, drawing mode, and color of the object without intervening with the dynamics.
	-It takes keyboard inputs for various purposes (quit, help, restart).
*/

#include "Angel.h"

typedef Angel::vec4  color4;
typedef Angel::vec4  point4;

//Physical variables for the object
float horizontalVelocity = 0.0005;
float verticalVelocity = 0.0;
float gravitationalAcc = 0.00005;

//One buffer is for cube, the other is for sphere.
//There should be simultaneously working buffers and VAOs to ease the switch between types immediately.
GLuint buffer, buffer2;
GLuint vaoArray[2];

//For cube
const int NumVertices = 36; //(6 faces)(2 triangles/face)(3 vertices/triangle)
point4 points[NumVertices];
color4 colors[NumVertices];
//

//For sphere
const int NumTimesToSubdivide = 5;
const int NumTrianglesForSphere = 4096;  // (4 faces)^(NumTimesToSubdivide + 1)
const int NumVerticesForSphere = 3 * NumTrianglesForSphere;

point4 pointsForSphere[NumVerticesForSphere];
vec3   normalsForSphere[NumVerticesForSphere];
//

//The menu options are shown in enums.
enum { cubeShape = 0, sphereShape = 1 };
int shape = cubeShape;

enum { solidMode = 0, wireframeMode = 1 };
int drawingMode = solidMode;

enum { black = 0, red = 1, yellow = 2, green = 3, blue = 4, magenta = 5, white = 6, cyan = 7 };
int colorOption = yellow;

// 
GLuint  ModelView, Projection;
mat4  transform;
// 

// Vertices of a unit cube centered at origin, sides aligned with axes
point4 vertices[8] = {
	point4(-0.5, -0.5,  0.5, 1.0),
	point4(-0.5,  0.5,  0.5, 1.0),
	point4( 0.5,  0.5,  0.5, 1.0),
	point4( 0.5, -0.5,  0.5, 1.0),
	point4(-0.5, -0.5, -0.5, 1.0),
	point4(-0.5,  0.5, -0.5, 1.0),
	point4( 0.5,  0.5, -0.5, 1.0),
	point4( 0.5, -0.5, -0.5, 1.0)
};

//Used for aligning the object to left-top corner
double factor = 1.8;

point4 verticesForCube[8] = {		//vertices for the small cube at the top leftmost corner
	point4(-factor - 0.1, factor - 0.1,  0.1, 1.0),
	point4(-factor - 0.1, factor + 0.1,  0.1, 1.0),
	point4(-factor + 0.1, factor + 0.1,  0.1, 1.0),
	point4(-factor + 0.1, factor - 0.1,  0.1, 1.0),
	point4(-factor - 0.1, factor - 0.1, -0.1, 1.0),
	point4(-factor - 0.1, factor + 0.1, -0.1, 1.0),
	point4(-factor + 0.1, factor + 0.1, -0.1, 1.0),
	point4(-factor + 0.1, factor - 0.1, -0.1, 1.0)
};

// RGBA olors
color4 vertex_colors[8] = {
    color4( 0.0, 0.0, 0.0, 1.0 ),  // black
    color4( 1.0, 0.0, 0.0, 1.0 ),  // red
    color4( 1.0, 1.0, 0.0, 1.0 ),  // yellow
    color4( 0.0, 1.0, 0.0, 1.0 ),  // green
    color4( 0.0, 0.0, 1.0, 1.0 ),  // blue
    color4( 1.0, 0.0, 1.0, 1.0 ),  // magenta
    color4( 1.0, 1.0, 1.0, 1.0 ),  // white
    color4( 0.0, 1.0, 1.0, 1.0 )   // cyan
};

// Array of rotation angles (in degrees) for each coordinate axis
enum { Xaxis = 0, Yaxis = 1, Zaxis = 2, NumAxes = 3 };
int      Axis = Xaxis;
GLfloat  Theta[NumAxes] = { 0.0, 0.0, 0.0 };

//----------------------------------------------------------------------------

// quad generates two triangles for each face and assigns colors
//    to the vertices
int Index = 0;
void
quad( int a, int b, int c, int d )
{
    colors[Index] = vertex_colors[colorOption]; points[Index] = verticesForCube[a]; Index++;
    colors[Index] = vertex_colors[colorOption]; points[Index] = verticesForCube[b]; Index++;
    colors[Index] = vertex_colors[colorOption]; points[Index] = verticesForCube[c]; Index++;
    colors[Index] = vertex_colors[colorOption]; points[Index] = verticesForCube[a]; Index++;
    colors[Index] = vertex_colors[colorOption]; points[Index] = verticesForCube[c]; Index++;
    colors[Index] = vertex_colors[colorOption]; points[Index] = verticesForCube[d]; Index++;
}

void changeColor(int colorOption) {
	for (int i = 0; i < NumVertices; i++) {
		colors[i] = vertex_colors[colorOption];
	}
}
//----------------------------------------------------------------------------

// generate 12 triangles: 36 vertices and 36 colors
void
colorcube()
{
    quad( 1, 0, 3, 2 );
    quad( 2, 3, 7, 6 );
    quad( 3, 0, 4, 7 );
    quad( 6, 5, 1, 2 );
    quad( 4, 5, 6, 7 );
    quad( 5, 4, 0, 1 );
}

//----------------------------------------------------------------------------
//Methods for drawing a sphere.
int Index2 = 0;

void
triangle( const point4& a, const point4& b, const point4& c )
{
    vec3  normal = normalize( cross(b - a, c - b) );

    normalsForSphere[Index2] = normal;  pointsForSphere[Index2] = a;  Index2++;
    normalsForSphere[Index2] = normal;  pointsForSphere[Index2] = b;  Index2++;
    normalsForSphere[Index2] = normal;  pointsForSphere[Index2] = c;  Index2++;
}

point4
unit( const point4& p )
{
    float len = p.x*p.x + p.y*p.y + p.z*p.z;
    
    point4 t;
    if ( len > DivideByZeroTolerance ) {
	t = p / sqrt(len);
	t.w = 1.0;
    }

    return t;
}

void
divide_triangle( const point4& a, const point4& b,
		 const point4& c, int count )
{
    if ( count > 0 ) {
        point4 v1 = unit( a + b );
        point4 v2 = unit( a + c );
        point4 v3 = unit( b + c );
        divide_triangle(  a, v1, v2, count - 1 );
        divide_triangle(  c, v2, v3, count - 1 );
        divide_triangle(  b, v3, v1, count - 1 );
        divide_triangle( v1, v3, v2, count - 1 );
    }
    else {
        triangle( a, b, c );
    }
}

double factor1 = 2.0;

void
tetrahedron( int count )
{
    point4 v[4] = {
	vec4( 0.0, 0.0, 1.0, 1.0 ),
	vec4( 0.0, 0.942809, -0.333333, 1.0 ),
	vec4( -0.816497, -0.471405, -0.333333, 1.0 ),
	vec4( 0.816497, -0.471405, -0.333333, 1.0 )
    };

    divide_triangle( v[0], v[1], v[2], count );
    divide_triangle( v[3], v[2], v[1], count );
    divide_triangle( v[0], v[3], v[1], count );
    divide_triangle( v[0], v[2], v[3], count );
}

//----------------------------------------------------------------------------

//----------------------------------------------------------------------------

bool initialize = true; //If the window is initialized for the first time. Required for color change

// OpenGL initialization
void
init()
{
	GLuint program = 0;
    GLuint vPosition;
    GLuint vColor;

	if (initialize)
	{
		colorcube();
		tetrahedron( NumTimesToSubdivide );

		// Load shaders and use the resulting shader program
		program = InitShader("vshader.glsl", "fshader.glsl");

		// Create a vertex array object for cube
        glGenVertexArrays( 2, vaoArray );

		////// Cube initialization
        glBindVertexArray( vaoArray[0] );

		glGenBuffers(1, &buffer);
		glBindBuffer(GL_ARRAY_BUFFER, buffer);
		glBufferData(GL_ARRAY_BUFFER, sizeof(points) + sizeof(colors), NULL, GL_STATIC_DRAW);
		glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(points), points);
		glBufferSubData(GL_ARRAY_BUFFER, sizeof(points), sizeof(colors), colors);

		// set up vertex arrays
		vPosition = glGetAttribLocation(program, "vPosition");
		glEnableVertexAttribArray(vPosition);
		glVertexAttribPointer(vPosition, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

		vColor = glGetAttribLocation(program, "vColor");
		glEnableVertexAttribArray(vColor);
		glVertexAttribPointer(vColor, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(sizeof(points)));

		//////Sphere initialization

		glBindVertexArray( vaoArray[1] );
        
        glGenBuffers( 1, &buffer2 );
    	glBindBuffer( GL_ARRAY_BUFFER, buffer2 );
    	glBufferData( GL_ARRAY_BUFFER, sizeof(pointsForSphere) + sizeof(normalsForSphere), NULL, GL_STATIC_DRAW );
    	glBufferSubData( GL_ARRAY_BUFFER, 0, sizeof(pointsForSphere), pointsForSphere );
    	glBufferSubData( GL_ARRAY_BUFFER, sizeof(pointsForSphere), sizeof(normalsForSphere), normalsForSphere );

        glEnableVertexAttribArray( vPosition );
        glVertexAttribPointer( vPosition, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0) );
        glEnableVertexAttribArray( vColor );
        glVertexAttribPointer( vColor, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(sizeof(pointsForSphere)) );
		
		///// Initialize shader lighting parameters
		point4 light_position( 0.0, 0.0, 2.0, 0.0 );
		color4 light_ambient( 0.2, 0.2, 0.2, 1.0 );
		color4 light_diffuse( 1.0, 1.0, 1.0, 1.0 );
		color4 light_specular( 1.0, 1.0, 1.0, 1.0 );

		color4 material_ambient( 1.0, 0.0, 1.0, 1.0 );
		color4 material_diffuse( 1.0, 0.8, 0.0, 1.0 );
		color4 material_specular( 1.0, 0.0, 1.0, 1.0 );
		float  material_shininess = 5.0;

		color4 ambient_product = light_ambient * material_ambient;
		color4 diffuse_product = light_diffuse * material_diffuse;
		color4 specular_product = light_specular * material_specular;

		glUniform4fv( glGetUniformLocation(program, "AmbientProduct"),
			1, ambient_product );
		glUniform4fv( glGetUniformLocation(program, "DiffuseProduct"),
			1, diffuse_product );
		glUniform4fv( glGetUniformLocation(program, "SpecularProduct"),
			1, specular_product );
		
		glUniform4fv( glGetUniformLocation(program, "LightPosition"),
			1, light_position );

		glUniform1f( glGetUniformLocation(program, "Shininess"),
			material_shininess );

		////

		ModelView = glGetUniformLocation(program, "ModelView");
		Projection = glGetUniformLocation(program, "Projection");

		// Set current program object
		glUseProgram(program);

		glEnable(GL_DEPTH_TEST);
		glClearColor(0.3, 0.1, 0.1, 0.3); //background color

		initialize = false;
	}
	else
	{
		//Cube 
		glBindBuffer(GL_ARRAY_BUFFER, buffer);
		glBufferData(GL_ARRAY_BUFFER, sizeof(points) + sizeof(colors), NULL, GL_STATIC_DRAW);
		glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(points), points);
		glBufferSubData(GL_ARRAY_BUFFER, sizeof(points), sizeof(colors), colors);
		vPosition = glGetAttribLocation(program, "vPosition");
		glEnableVertexAttribArray(vPosition);
		glVertexAttribPointer(vPosition, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));
		vColor = glGetAttribLocation(program, "vColor");
		glEnableVertexAttribArray(vColor);
		glVertexAttribPointer(vColor, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(sizeof(points)));

		//Sphere
		glBindBuffer( GL_ARRAY_BUFFER, buffer2 );
    	glBufferData( GL_ARRAY_BUFFER, sizeof(pointsForSphere) + sizeof(normalsForSphere), NULL, GL_STATIC_DRAW );
    	glBufferSubData( GL_ARRAY_BUFFER, 0, sizeof(pointsForSphere), pointsForSphere );
    	glBufferSubData( GL_ARRAY_BUFFER, sizeof(pointsForSphere), sizeof(normalsForSphere), normalsForSphere );
        glEnableVertexAttribArray( vPosition );
        glVertexAttribPointer( vPosition, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0) );
        glEnableVertexAttribArray( vColor );
        glVertexAttribPointer( vColor, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(sizeof(pointsForSphere)) );
	
	}
}

//----------------------------------------------------------------------------
vec3 velocity = vec3(0.0, 0.0, 0.0);
bool restartProgram = false; 

void
display( void )
{
	if(shape == cubeShape){
        glBindVertexArray( vaoArray[0] );
    } else if(shape == sphereShape){ //swap between cube and sphere objects
        glBindVertexArray( vaoArray[1] );
		//velocity = vec3(0.0, 0.0, 0.0); // don't forget
    }

	if(!restartProgram)
	{
		transform = (Scale(0.5, 0.5, 1.0) * Translate(velocity));
	}
	else
	{
		transform[0] = -factor - 0.1;
		transform[1] = factor - 0.1;
		verticalVelocity = 0.0;
		velocity = vec3(0.0, 0.0, 0.0);
		restartProgram = false;
	}
	
	glUniformMatrix4fv( ModelView, 1, GL_TRUE, transform );
    
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    
    glDrawArrays( GL_TRIANGLES, 0, NumVertices );

	//Swap between shapes and drawing modes
	if(shape == cubeShape && drawingMode == solidMode)
	{
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
        glDrawArrays( GL_TRIANGLES, 0, NumVertices );
    } 
	else if(shape == cubeShape && drawingMode == wireframeMode)
	{
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
        glDrawArrays( GL_LINES, 0, NumVertices );
    } 	
	else if(shape == sphereShape && drawingMode == solidMode)
	{
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
        glDrawArrays( GL_TRIANGLES, 0, NumVerticesForSphere );
    } 
	else 
	{
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
        glDrawArrays( GL_LINES, 0, NumVerticesForSphere );
    }

    glutSwapBuffers();
}

//----------------------------------------------------------------------------

void
keyboard( unsigned char key,int x, int y )
{
    if(key == 'Q' | key == 'q')
        exit(0);
    else if(key == 'H' | key == 'h'){
        std::cout << "-- Help Menu--" << std::endl;
        std::cout << "\nKey --> Function\n" << std::endl;
        std::cout << "Q --> Quit" << std::endl;
        std::cout << "I --> Restart the bouncing" << std::endl;
        std::cout << "H --> Help" << std::endl;
    } else if (key == 'I' | key == 'i'){
		restartProgram = true;
		//transform[2] = 0.1;
    }
}

//----------------------------------------------------------------------------

void
mouse( int button, int state, int x, int y )
{
    
}

//----------------------------------------------------------------------------
bool downwards = true; 
//Change object's velocity to make it bounce
void
idle( void )
{
    velocity[0] = velocity[0] + horizontalVelocity;
	
	//double ground = 3.75;

	if(verticalVelocity <= 0)
	{
		downwards = true;
	}
	else if(velocity[1] < -3.75 )
	{
		downwards = false;
		float verticalVelocity2 = verticalVelocity;
		verticalVelocity = verticalVelocity * 0.9;	//Velocity decreases 10% each time object hits the ground
		if((verticalVelocity2 - verticalVelocity) < 0.0001)
		{
			restartProgram = true;
		}
	}
	if(downwards) //gets faster as it goes down
	{
		velocity[1] = velocity[1] - verticalVelocity;
		verticalVelocity = verticalVelocity + gravitationalAcc;
	}
	else //gets slower as it goes up
	{
		velocity[1] = velocity[1] + verticalVelocity;
		verticalVelocity = verticalVelocity - gravitationalAcc;
	}
	
	glutPostRedisplay();
}

//----------------------------------------------------------------------------

void 
reshape( int width, int height )
{
    glViewport( 0, 0, width, height);
    
    mat4  projection;
    if (width <= height)
        projection = Ortho(-1.0, 1.0, -1.0 * (GLfloat) height / (GLfloat) width,
                           1.0 * (GLfloat) height / (GLfloat) width, -1.0, 1.0);
    else  projection = Ortho(-1.0* (GLfloat) width / (GLfloat) height, 1.0 *
                             (GLfloat) width / (GLfloat) height, -1.0, 1.0, -1.0, 1.0);
        
    glUniformMatrix4fv( Projection, 1, GL_TRUE, projection );
    
}

//Callbacks for menu options
void objectTypeCallback(int id)
{
	switch (id) {
	case 1:
		shape = cubeShape;
		break;
	case 2:
		shape = sphereShape;
		break;
	}
	glutPostRedisplay();
}

void drawingModeCallback(int id)
{
	switch (id) {
	case 1:
		drawingMode = solidMode;
		break;
	case 2:
		drawingMode = wireframeMode;
		break;
	}
	glutPostRedisplay();
}

void colorCallback(int id)
{
	switch (id) {
	case 1:
		colorOption = black;
		break;
	case 2:
		colorOption = red;
		break;
	case 3:
		colorOption = yellow;
		break;
	case 4:
		colorOption = green;
		break;
	case 5:
		colorOption = blue;
		break;
	case 6:
		colorOption = magenta;
		break;
	case 7:
		colorOption = white;
		break;
	case 8:
		colorOption = cyan;
		break;
	}
	changeColor(colorOption);
	init();
	glutPostRedisplay();
}


int
main( int argc, char **argv )
{
    glutInit( &argc, argv );
    glutInitDisplayMode( GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH  );
    glutInitWindowSize( 512, 512 );
    glutInitWindowPosition( 50, 50 );
    glutCreateWindow( "acagatay14 - Assignment1" );

	int objectTypeSubMenu = glutCreateMenu(objectTypeCallback);
	glutAddMenuEntry("Cube", 1);
	glutAddMenuEntry("Sphere", 2);

	int drawingModeSubMenu = glutCreateMenu(drawingModeCallback);
	glutAddMenuEntry("Solid", 1);
	glutAddMenuEntry("Wireframe", 2);

	int colorSubMenu = glutCreateMenu(colorCallback);
	glutAddMenuEntry("Black", 1);
	glutAddMenuEntry("Red", 2);
	glutAddMenuEntry("Yellow", 3);
	glutAddMenuEntry("Green", 4);
	glutAddMenuEntry("Blue", 5);
	glutAddMenuEntry("Magenta", 6);
	glutAddMenuEntry("White", 7);
	glutAddMenuEntry("Cyan", 8);

	glutCreateMenu(NULL);
	glutAddSubMenu("Object Type", objectTypeSubMenu);
	glutAddSubMenu("Drawing Mode", drawingModeSubMenu);
	glutAddSubMenu("Color", colorSubMenu);
	glutAttachMenu(GLUT_RIGHT_BUTTON);

    printf("Supported GLSL version is %s.\n", glGetString(GL_SHADING_LANGUAGE_VERSION));
    printf("%s\n%s\n%s\n",
           glGetString(GL_RENDERER),  // e.g. Intel HD Graphics 3000 OpenGL Engine
           glGetString(GL_VERSION),    // e.g. 3.2 INTEL-8.0.61
           glGetString(GL_SHADING_LANGUAGE_VERSION));

    glewExperimental = GL_TRUE;
    glewInit();

    init();

    glutDisplayFunc( display );
    glutKeyboardFunc( keyboard );
    glutMouseFunc( mouse );
    glutIdleFunc( idle );
    glutReshapeFunc( reshape );

    glutMainLoop();

    return 0;
}
