#include "Angel.h"
#include "time.h"
#include "models.h"
#include <stdlib.h>

using namespace models;
using namespace std;

// timing related variables
GLfloat currTime = 0;
const GLfloat deltaTime = .033;

// index of current model
int currentModel = CUBE;

// physics //
	// initial values for simulation
const vec3 ini_pos = vec3(-1.0, 1.0, 0.0);
const vec3 ini_vel = vec3(0.8, 0.0, 0.0);

vec3 pos = ini_pos;
vec3 vel = ini_vel;
const vec3 acc = vec3(0.0, -2, 0.0);
	// velocity multiplier for each collision 
const GLfloat dampFactor = 0.9;

// bounds for side collision and resizing
typedef struct bounds {
	GLfloat xMin;
	GLfloat xMax;
	GLfloat yMin;
	GLfloat yMax;
} Bounds;

Bounds bounds = { -1, 1, -1, 1 };

// scale of the model 
const GLfloat defaultModelScale = 0.20;
// global variable to control scale for different models
GLfloat modelScale = defaultModelScale;

// color options for color menu
enum {
	RED = 0,
	GREEN = 1,
	BLUE = 2,
	YELLOW = 3,
	CYAN = 4,
	MAGENTA = 5,
	WHITE = 6,
	BLACK = 7,
	NUM_COLORS = 8
};

enum{ perspective = 1 , ortho = 2};
int projectionOption = ortho;

enum{ gouraud = 1 , phong = 2, modifiedPhong = 3};
bool modifiedFlag = false;
GLuint ModifiedPhongFlag;
bool gouraudFlag = false;

GLuint textures[2];
int TextureWidthSizes[2] = {512, 2048};
int TextureHeightSizes[2] = {256, 1024};
GLubyte imageBasketball[512][256][3];
GLubyte imageEarth[2048][1024][3];
bool textureFlag = true; 
GLuint TextureFlag; 

const color4 colorOptions[NUM_COLORS] = {
	color4(1,0,0,1),
	color4(0,1,0,1),
	color4(0,0,1,1),
	color4(1,1,0,1),
	color4(0,1,1,1),
	color4(1,0,1,1),
	color4(1,1,1,1),
	color4(0,0,0,1)
};

// VBOs and VAOs
GLuint buffers[NUM_MODELS];
GLuint vaos[NUM_MODELS];

// shader uniforms 
GLuint modelviewUniLoc;
GLuint projectionUniLoc;
GLuint colorUniLoc;

//----------------------------------------------------------------------------

bool
readPPM(char* name, int indicator){
    
    string fileName(name);
    string path = "/Users/aecag/Documents/COMP410/COMP410_assignment3_acagatay14/COMP410_assignment3_acagatay14/" + fileName;
    
    const char* pathAsPointer = path.c_str();    
    
    int k, n, m, nm;
    char c;
    int i;
    char b[100];
    int red, green, blue;
    FILE * fd = fopen(pathAsPointer, "r"); 
	
    if( fd == NULL ){
        cout << "File cannot be opened!" << endl;
        return false;
    }
    
    fscanf(fd,"%[^\n] ",b);
    
    if(b[0]!='P' || b[1] != '3'){
        printf("%s is not a PPM file!\n", b);
        exit(0);
    }

    printf("%s is a PPM file\n",b);
    fscanf(fd, "%c",&c);
    while(c == '#') {
        fscanf(fd, "%[^\n] ", b);
        printf("%s\n",b);
        fscanf(fd, "%c",&c);
    }

    ungetc(c,fd);
    fscanf(fd, "%d %d %d", &n, &m, &k);
    nm = n*m;
    
	for(int i = 0; i < n; i++){
		for(int j = 0; j < m; j++){
			fscanf(fd,"%d %d %d",&red, &green, &blue );
			if(indicator == 0)
			{
				imageBasketball[n-i-1][j][0] = (GLubyte)red;
				imageBasketball[n-i-1][j][1] = (GLubyte)green;
				imageBasketball[n-i-1][j][2] = (GLubyte)blue;
			}
			else
			{
				imageEarth[n-i-1][j][0] = (GLubyte)red;
				imageEarth[n-i-1][j][1] = (GLubyte)green;
				imageEarth[n-i-1][j][2] = (GLubyte)blue;
			}
			
			
		}
	}
        
    fclose(fd);
    
    return true;
}

void 
usage() {
	cout <<
		"---------------------------" << endl <<
		"   Bouncing Object Program" << endl <<
		"   Usage: " << endl <<
		"      Click to access the menu" << endl <<
		"      i - initialize pose at top left" << endl <<
		"      r - add a random velocity to the ball" << endl <<
		"      q - quit program" << endl <<
		"      h - print this help message" << endl;
}


// OpenGL initialization
void
init()
{
	char* basketballText = (char *) "basketball.ppm";
    char* earthText = (char *) "earth.ppm";

	readPPM(basketballText, 0);
	readPPM(earthText, 1);

	glGenTextures( 2, textures );
    
    glBindTexture( GL_TEXTURE_2D, textures[0] );
    
    glTexImage2D( GL_TEXTURE_2D, 0, GL_RGB, TextureWidthSizes[0], TextureHeightSizes[0], 0,
                 GL_RGB, GL_UNSIGNED_BYTE, imageBasketball );
    glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST_MIPMAP_LINEAR); 
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); 

	glBindTexture( GL_TEXTURE_2D, textures[1] );
    
    glTexImage2D( GL_TEXTURE_2D, 0, GL_RGB, TextureWidthSizes[1], TextureHeightSizes[1], 0,
                 GL_RGB, GL_UNSIGNED_BYTE, imageEarth );
    glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST_MIPMAP_LINEAR); 
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); 
    

	// print help to console
	usage();

	// load model data into arrays (from models.h)
	cube();
	sphere();
	bunny();

	// Load shaders and use the resulting shader program
	GLuint program;
	if(gouraudFlag){
        program = InitShader( "vshader.glsl", "fshader.glsl" );
    } else {
        program = InitShader( "vshader_phong.glsl", "fshader_phong.glsl" );
    }
	glUseProgram(program);

	// uniforms 
	modelviewUniLoc = glGetUniformLocation(program, "modelview");
	projectionUniLoc = glGetUniformLocation(program, "projection");
	// all vertices will have the same color in this program
	// so we pass te color into the shader as a uniform
	colorUniLoc = glGetUniformLocation(program, "color");
	glUniform4fv(colorUniLoc, 1, colorOptions[WHITE]);

	// create VBOs and VAOs
	glGenBuffers(NUM_MODELS, buffers);
	glGenVertexArrays(NUM_MODELS, vaos);

	for (int i = 0; i < NUM_MODELS; i++) {
		// initialize buffers 
		glBindBuffer(GL_ARRAY_BUFFER, buffers[i]);
		glBufferData(GL_ARRAY_BUFFER, model_pts_sizes[i], NULL, GL_STATIC_DRAW);
		glBufferSubData(GL_ARRAY_BUFFER, 0, model_pts_sizes[i], model_pts[i]);

		// set up vertex arrays
		glBindVertexArray(vaos[i]);

		GLuint vPosition = glGetAttribLocation(program, "vPosition");
		glEnableVertexAttribArray(vPosition);
		glVertexAttribPointer(vPosition, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));
	}
	// Initialize shader lighting parameters
    point4 light_position( -1.0, 0.0, 0.0, 1.0 ); // point
    color4 light_ambient( 0.2, 0.2, 0.2, 1.0 ); // L_a
    color4 light_diffuse( 1.0, 1.0, 1.0, 1.0 ); // L_d
    color4 light_specular( 1.0, 1.0, 1.0, 1.0 ); // L_s
    
    color4 material_ambient( 1.0, 0.0, 1.0, 1.0 ); // k_a
    color4 material_diffuse( 1.0, 0.8, 0.0, 1.0 ); // k_d
    color4 material_specular( 1.0, 0.8, 0.0, 1.0 ); // k_s
    float  material_shininess = 100.0;
    
    
    // Initialize shader lighting parameters
    point4 light_position2( 1.0, 0.0, 0.0, 0.0 ); // directional
    
    
    color4 ambient_product = light_ambient * material_ambient; // k_a * L_a
    color4 diffuse_product = light_diffuse * material_diffuse; // k_d * L_d
    color4 specular_product = light_specular * material_specular; // k_s * L_s
    glUniform4fv( glGetUniformLocation(program, "AmbientProduct"),
                 1, ambient_product );
    glUniform4fv( glGetUniformLocation(program, "DiffuseProduct"),
                 1, diffuse_product );
    glUniform4fv( glGetUniformLocation(program, "SpecularProduct"),
                 1, specular_product );
    
    glUniform4fv( glGetUniformLocation(program, "LightPosition"),
                 1, light_position );
    
    glUniform4fv( glGetUniformLocation(program, "LightPosition2"),
                 1, light_position2 );
    
    glUniform1f( glGetUniformLocation(program, "Shininess"),
                material_shininess );

	// default object is the cube
	glBindVertexArray(vaos[currentModel]);

	glEnable(GL_DEPTH_TEST);
	glClearColor(0.0, 0.0, 0.0, 1.0);
}

//----------------------------------------------------------------------------

void
display(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// update the transform of the object 
	mat4 transform = Translate(pos)
		* RotateX(currTime * 72) // constant rotation around 2 axes
		* RotateY(currTime * 20) // to appriciate all 3 dimensions
		* Scale(modelScale);

	// pass transform into shader
	glUniformMatrix4fv(modelviewUniLoc, 1, GL_TRUE, transform);

	// select data to be drawn
	glBufferSubData(GL_ARRAY_BUFFER, 0, model_pts_sizes[currentModel], model_pts[currentModel]);
	
	// draw to backbuffer
	glDrawArrays(GL_TRIANGLES, 0, NumVertices[currentModel]);
	
	// show rendered buffer
	glutSwapBuffers();
}

//----------------------------------------------------------------------------

void
keyboard(unsigned char key, int x, int y)
{
	switch (key) {
	// quit program
	case 'q': case 'Q': case 033:  // Escape key
		exit(EXIT_SUCCESS);
		break;

	// return to inital state
	case 'i': case 'I':
		pos = vec3(bounds.xMin, bounds.yMax, 0.0);;
		vel = ini_vel;
		break;

	// add a random velocity
	case 'r': case 'R':
		vel.x = (GLfloat) 2.0 * (((rand() % 1000) / 1000.0) - 0.5);
		vel.y += (GLfloat) 2.0 * (rand() % 1000 / 1000.0);
		break;

	// print help to console
	case 'h': case 'H':
		usage();
		break;
	}
}

//----------------------------------------------------------------------------

void timer(int p) {
	currTime += deltaTime;

	// basic forward Euler integration 
	vel += acc * deltaTime;
	pos += vel * deltaTime;

	// bounds checking and bounce with damping
	if (pos.y < bounds.yMin + modelScale) {
		pos.y = bounds.yMin + modelScale;
		vel.y *= -1;
		vel *= dampFactor;
	}
	else if (pos.y > bounds.yMax - modelScale) {
		pos.y = bounds.yMax - modelScale;
		vel.y *= -1;
		vel *= dampFactor;
	}

	if (pos.x < bounds.xMin + modelScale) {
		pos.x = bounds.xMin + modelScale;
		vel.x *= -1;
		vel *= dampFactor;
	}
	else if (pos.x > bounds.xMax - modelScale) {
		pos.x = bounds.xMax - modelScale;
		vel.x *= -1;
		vel *= dampFactor;
	}

	glutPostRedisplay();

	glutTimerFunc(33, timer, 0);
}

//----------------------------------------------------------------------------

void reshape(int w, int h)
{
	glViewport(0, 0, w, h);

    mat4  projection;
    
    if(projectionOption == 1){
        if (w <= h){
            projection = Perspective( 45.0, (GLfloat) w / (GLfloat) h, 0.1, 100 );
        } else {
            projection = Perspective( 45.0, (GLfloat) w / (GLfloat) h, 0.1, 100 );
        }
    } else {
        if (w <= h){
            projection = Ortho(-1.0, 1.0, -1.0 * (GLfloat) h / (GLfloat) w, 1.0 * (GLfloat) h / (GLfloat) w, -1.0, 1.0);
        } else  {
            projection = Ortho(-1.0* (GLfloat) w / (GLfloat) h, 1.0 * (GLfloat) w / (GLfloat) h, -1.0, 1.0, -1.0, 1.0);
        }
    }

	glUniformMatrix4fv(projectionUniLoc, 1, GL_TRUE, projection);
}


////// menu callbacks //////
void 
objectMenuCallback (int id) {
	// change current object
	currentModel = id;

	// bind its VAO
	glBindVertexArray(vaos[currentModel]);
	
	// adjust model scale for the bunny
	if (currentModel == BUNNY) modelScale = bunnyScale * defaultModelScale;
	else modelScale = defaultModelScale;

}

void
drawingMenuCallback(int id) {
	if (id == 0) glPolygonMode( GL_FRONT_AND_BACK, GL_LINE ); 	// wireframe
	if (id == 1) glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );	// solid
}

void
colorMenuCallback(int id) {
	glUniform4fv(colorUniLoc, 1, colorOptions[id]);
}

void projectionCallback(int id)
{
    switch(id) {
        case 1:
            projectionOption = perspective;
            break;
        case 2:
            projectionOption = ortho;
            break;
    }
    reshape(glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT));
    glutPostRedisplay();
}

void shadingCallback(int id)
{
	
    switch(id) {
        case 1:
            modifiedFlag = false;
            glUniform1i( ModifiedPhongFlag, modifiedFlag );
            gouraudFlag = true;
            init();
            reshape(glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT));
            break;
        case 2:
            modifiedFlag = false;
            gouraudFlag = false;
            glUniform1i( ModifiedPhongFlag, modifiedFlag );
            init();
            reshape(glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT));
            break;
        case 3: // to see this effect, please focus the light on the center of a surface of a cube and change between gouraud and this, you will see that they're different.
            modifiedFlag = true;
            gouraudFlag = false;
            init();
            reshape(glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT));
            glUniform1i( ModifiedPhongFlag, modifiedFlag );
            break;
    }
    glutPostRedisplay();
	
}

void
mainMenu(int id) { }

// setting up the right click menu
void initMenus() {
	int objectMenu = glutCreateMenu(objectMenuCallback);
	glutAddMenuEntry("Cube", CUBE);
	glutAddMenuEntry("Sphere", SPHERE);
	glutAddMenuEntry("Bunny", BUNNY);

	int drawingMenu = glutCreateMenu(drawingMenuCallback);
	glutAddMenuEntry("Wireframe", 0);
	glutAddMenuEntry("Solid", 1);

	int colorMenu = glutCreateMenu(colorMenuCallback);
	glutAddMenuEntry("Red", RED);
	glutAddMenuEntry("Green", GREEN);
	glutAddMenuEntry("Blue", BLUE);
	glutAddMenuEntry("Yellow", YELLOW);
	glutAddMenuEntry("Cyan", CYAN);
	glutAddMenuEntry("Magenta", MAGENTA);
	glutAddMenuEntry("White", WHITE);
	glutAddMenuEntry("Black", BLACK);

	 int projectionSubMenu = glutCreateMenu(projectionCallback);
    glutAddMenuEntry("Perspective", 1);
    glutAddMenuEntry("Ortho", 2);

	int shadingSubMenu = glutCreateMenu(shadingCallback);
    glutAddMenuEntry("Gouraud", 1);
    glutAddMenuEntry("Phong", 2);
    glutAddMenuEntry("Modified Phong", 3);

	int rmenu = glutCreateMenu(mainMenu);
	glutAddSubMenu("Object Type", objectMenu);
	glutAddSubMenu("Drawing Mode", drawingMenu);
	glutAddSubMenu("Color", colorMenu);
	glutAddSubMenu("Projection", projectionSubMenu);
	glutAddSubMenu("Shading", shadingSubMenu);

	// any click will open up the pop up menu
	glutAttachMenu(GLUT_RIGHT_BUTTON);
	glutAttachMenu(GLUT_LEFT_BUTTON);
	glutAttachMenu(GLUT_MIDDLE_BUTTON);
}


////// main //////
int
main(int argc, char **argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowSize(512, 512);
	glutInitWindowPosition(50, 50);
	glutCreateWindow("Bouncing Object");

	printf("Supported GLSL version is %s.\n", glGetString(GL_SHADING_LANGUAGE_VERSION));
	printf("%s\n%s\n%s\n",
		glGetString(GL_RENDERER),  // e.g. Intel HD Graphics 3000 OpenGL Engine
		glGetString(GL_VERSION),    // e.g. 3.2 INTEL-8.0.61
		glGetString(GL_SHADING_LANGUAGE_VERSION));

	glewExperimental = GL_TRUE;
	glewInit();

	// initialize models and OpenGL
	init();
	initMenus();

	// bind callbacks
	glutDisplayFunc(display);
	glutKeyboardFunc(keyboard);
	//glutIdleFunc(idle);
	glutTimerFunc(33, timer, 0);
	glutReshapeFunc(reshape);

	glutMainLoop();

	return 0;
}