/*
	Ahmet Erdem Cagatay - 49826
	COMP410 - Assignment #2
*/

#include "Angel.h"

using namespace std;

typedef vec4  color4;
typedef vec4  point4;

GLuint vaoArray[8];  
GLuint buffer;
GLuint vPosition;
GLuint vColor;

GLuint  ModelView, Projection;

const int NumVertices = 36;

mat4  ModelViews[8];  

GLfloat offset = 0.025;
GLfloat cubeLine = 0.2; 

point4 Points[8][NumVertices] = {};  
point4 Colors[8][NumVertices] = {};  

point4 MultipleCubeVertices[8][8] = {};  

point4 xCoordinates[8] = { 
    /* Front 4 */
    point4(-cubeLine-offset,0.0,0.0,0.0), point4(+cubeLine+offset,0.0,0.0,0.0),
    point4(-cubeLine-offset,0.0,0.0,0.0), point4(+cubeLine+offset,0.0,0.0,0.0),
    
    /* Back 4 */
    point4(-cubeLine-offset,0.0,0.0,0.0), point4(+cubeLine+offset,0.0,0.0,0.0),
    point4(-cubeLine-offset,0.0,0.0,0.0), point4(+cubeLine+offset,0.0,0.0,0.0)
};
point4 yCoordinates[8] = { 
    /* Front 4 */
    point4(0.0,+cubeLine+offset,0.0,0.0), point4(0.0,+cubeLine+offset,0.0,0.0),
    point4(0.0,-cubeLine-offset,0.0,0.0), point4(0.0,-cubeLine-offset,0.0,0.0), 

    /* Back 4 */
    point4(0.0,+cubeLine+offset,0.0,0.0), point4(0.0,+cubeLine+offset,0.0,0.0),
    point4(0.0,-cubeLine-offset,0.0,0.0), point4(0.0,-cubeLine-offset,0.0,0.0)
};
point4 zCoordinates[8] = { 
    /* Front 4 */
    point4(0.0,0.0,+cubeLine+offset,0.0), point4(0.0,0.0,+cubeLine+offset,0.0), 
    point4(0.0,0.0,+cubeLine+offset,0.0), point4(0.0,0.0,+cubeLine+offset,0.0), 
       
    /* Back 4 */
    point4(0.0,0.0,-cubeLine-offset,0.0), point4(0.0,0.0,-cubeLine-offset,0.0), 
    point4(0.0,0.0,-cubeLine-offset,0.0), point4(0.0,0.0,-cubeLine-offset,0.0)
};

point4 SingleCubeVertices[8] = {
    point4( -cubeLine, -cubeLine,  cubeLine, 1.0 ),
    point4( -cubeLine,  cubeLine,  cubeLine, 1.0 ),
    point4(  cubeLine,  cubeLine,  cubeLine, 1.0 ),
    point4(  cubeLine, -cubeLine,  cubeLine, 1.0 ),
    point4( -cubeLine, -cubeLine, -cubeLine, 1.0 ),
    point4( -cubeLine,  cubeLine, -cubeLine, 1.0 ),
    point4(  cubeLine,  cubeLine, -cubeLine, 1.0 ),
    point4(  cubeLine, -cubeLine, -cubeLine, 1.0 )
};

void assignCubeVertices(){  
    
    for(int i = 0; i < 8; i++){        
        for(int j = 0; j < 9 ; j++){            
            MultipleCubeVertices[i][j]   = SingleCubeVertices[j] + xCoordinates[i] + yCoordinates[i] + zCoordinates[i];
        }
    }   
}

color4 MultipleCubeColors[8][6] = {  
    {
        //front 4
        color4( 0.0, 0.0, 1.0, 1.0 ),  // blue
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
        color4( 1.0, 1.0, 0.0, 1.0 ),  // yellow
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
        color4( 1.0, 0.5, 0.0, 1.0 )   // orange
    },
    {
        color4( 0.0, 0.0, 1.0, 1.0 ),  // blue
        color4( 1.0, 0.0, 0.0, 1.0 ),  // red
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
        color4( 1.0, 1.0, 0.0, 1.0 ),  // yellow
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
    },
    {
        color4( 0.0, 0.0, 1.0, 1.0 ),  // blue
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
        color4( 0.0, 1.0, 0.0, 1.0 ),  // green
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
        color4( 1.0, 0.5, 0.0, 1.0 )   // orange
    },
    {
        color4( 0.0, 0.0, 1.0, 1.0 ),  // blue
        color4( 1.0, 0.0, 0.0, 1.0 ),  // red
        color4( 0.0, 1.0, 0.0, 1.0 ),  // green
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
        color4( 0.0, 0.0, 0.0, 1.0 )   // black
    },
    {
        //back 4
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
        color4( 1.0, 1.0, 0.0, 1.0 ),  // yellow
        color4( 1.0, 1.0, 1.0, 1.0 ),  // white
        color4( 1.0, 0.5, 0.0, 1.0 )   // orange
    },
    {
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
        color4( 1.0, 0.0, 0.0, 1.0 ),  // red
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
        color4( 1.0, 1.0, 0.0, 1.0 ),  // yellow
        color4( 1.0, 1.0, 1.0, 1.0 ),  // white
        color4( 0.0, 0.0, 0.0, 1.0 )   // black
    },
    {
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
        color4( 0.0, 1.0, 0.0, 1.0 ),  // green
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
        color4( 1.0, 1.0, 1.0, 1.0 ),  // white
        color4( 1.0, 0.5, 0.0, 1.0 ),  // orange
    },
    {
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
        color4( 1.0, 0.0, 0.0, 1.0 ),  // red
        color4( 0.0, 1.0, 0.0, 1.0 ),  // green
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
        color4( 1.0, 1.0, 1.0, 1.0 ),  // white
        color4( 0.0, 0.0, 0.0, 1.0 ),  // black
    }
};

int Index = 0;
void
quad( int a, int b, int c, int d, int cubeIndex, int face )
{
    Colors[cubeIndex][Index] = MultipleCubeColors[cubeIndex][face]; Points[cubeIndex][Index] = MultipleCubeVertices[cubeIndex][a]; Index++;
    Colors[cubeIndex][Index] = MultipleCubeColors[cubeIndex][face]; Points[cubeIndex][Index] = MultipleCubeVertices[cubeIndex][b]; Index++;
    Colors[cubeIndex][Index] = MultipleCubeColors[cubeIndex][face]; Points[cubeIndex][Index] = MultipleCubeVertices[cubeIndex][c]; Index++;
    Colors[cubeIndex][Index] = MultipleCubeColors[cubeIndex][face]; Points[cubeIndex][Index] = MultipleCubeVertices[cubeIndex][a]; Index++;
    Colors[cubeIndex][Index] = MultipleCubeColors[cubeIndex][face]; Points[cubeIndex][Index] = MultipleCubeVertices[cubeIndex][c]; Index++;
    Colors[cubeIndex][Index] = MultipleCubeColors[cubeIndex][face]; Points[cubeIndex][Index] = MultipleCubeVertices[cubeIndex][d]; Index++;
}

void
colorcube(int cubeIndex)
{
    quad( 1, 0, 3, 2, cubeIndex, 0  );
    quad( 2, 3, 7, 6, cubeIndex, 1  );
    quad( 3, 0, 4, 7, cubeIndex, 2  );
    quad( 6, 5, 1, 2, cubeIndex, 3  );
    quad( 4, 5, 6, 7, cubeIndex, 4  );
    quad( 5, 4, 0, 1, cubeIndex, 5  );
    Index = 0;
}

enum { Xaxis = 0, Yaxis = 1, Zaxis = 2, NumAxes = 3 };

GLfloat  initialAxisPositioning[NumAxes] = { 20.0, -20.0, 0.0 };

//Indexes of cubes are assigned to arrays to apply transformations
int rightFace[4] = {1,3,5,7};
int leftFace[4] = {0,2,4,6};
int frontFace[4] = {0,1,2,3};
int behindFace[4] = {4,5,6,7};
int aboveFace[4] = {0,1,4,5};
int belowFace[4] = {2,3,6,7};

int rightFaceTemp[4] = { };
int leftFaceTemp[4] = { };
int frontFaceTemp[4] = { };
int behindFaceTemp[4] = { };
int aboveFaceTemp[4] = { };
int belowFaceTemp[4] = { };

void alignFaceTemp(){
    
    for(int j = 0; j < 4; j++){
        rightFaceTemp[j] = rightFace[j];
    }
    
    for(int j = 0; j < 4; j++){
        leftFaceTemp[j] = leftFace[j];
    }
    
    for(int j = 0; j < 4; j++){
        frontFaceTemp[j] = frontFace[j];
    }
   
    for(int j = 0; j < 4; j++){
        behindFaceTemp[j] = behindFace[j];
    }
    
    for(int j = 0; j < 4; j++){
        aboveFaceTemp[j] = aboveFace[j];
    }
    
    for(int j = 0; j < 4; j++){
        belowFaceTemp[j] = belowFace[j];
    }
}

int findMaxArr(int arr[]){
    int max = -1;
    for(int i = 0; i < 4; i++){
        if(arr[i] > max){
            max = arr[i];
        }
    }
    return max;
}

//Angles used for applying transformations
GLfloat  FaceAxisPositioningCCW[NumAxes] = { 0.0, 0.0, 0.0 }; 
GLfloat  FaceAxisPositioningCW[NumAxes] = { 0.0, 0.0, 0.0 }; 

GLfloat ViewAxisPositioningCCW[NumAxes] = {0.0, 0.0, 0.0}; 
GLfloat ViewAxisPositioningCW[NumAxes] = {0.0, 0.0, 0.0}; 

//booleans for side and view checks
bool ViewBoolYCCW = false;
bool ViewBoolYCW = false;
bool ViewBoolXCCW = false;
bool ViewBoolXCW = false;
bool FaceBoolX = false;
bool FaceBoolZ = false;
bool FaceBoolY = false;
bool FaceViewBoolX = false;
bool FaceViewBoolZ = false;
bool FaceViewBoolY = false;

//keyboard variables
bool keyLeftPressed = false; 
bool keyRightPressed = false; 
bool keyUpPressed = false; 
bool keyDownPressed = false; 
bool keyOnePressed = false; 
bool keyTwoPressed = false; 
bool keyThreePressed = false; 
bool keyFourPressed = false; 
bool keyFivePressed = false; 
bool keySixPressed = false; 
bool keyAnyPressed = false; 


void
init()
{
    assignCubeVertices();
    
    for(int i = 0; i < 8; i++){
        colorcube(i);
    }
    
    GLuint program = program = InitShader("vshader.glsl", "fshader.glsl");
    
    glGenVertexArrays( 8, vaoArray );
    for (int i = 0; i < 8; i++) {
        
        glBindVertexArray( vaoArray[i] );
        glGenBuffers( 1, &buffer );
        glBindBuffer( GL_ARRAY_BUFFER, buffer );
        glBufferData( GL_ARRAY_BUFFER, sizeof(point4)*36 + sizeof(Colors[i]), NULL, GL_STATIC_DRAW );
        glBufferSubData( GL_ARRAY_BUFFER, 0, sizeof(point4)*36, Points[i] );
        glBufferSubData( GL_ARRAY_BUFFER, sizeof(point4)*36, sizeof(Colors[i]), Colors[i] );
        
        vPosition = glGetAttribLocation( program, "vPosition" );
        
        glEnableVertexAttribArray( vPosition );
        glVertexAttribPointer( vPosition, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0) );
        
        vColor = glGetAttribLocation( program, "vColor" );
        glEnableVertexAttribArray( vColor );
        glVertexAttribPointer( vColor, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(sizeof(point4)*36) );              
        
        ModelViews[i] =  RotateY( initialAxisPositioning[Yaxis] ) * RotateX( initialAxisPositioning[Xaxis] ) * ModelViews[i];
    }
    
    ModelView = glGetUniformLocation( program, "ModelView" );
    Projection = glGetUniformLocation( program, "Projection" );
    
    glUseProgram( program );
    
    mat4  projection;
    projection = Ortho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0); 
    glUniformMatrix4fv( Projection, 1, GL_TRUE, projection );
    
    glEnable( GL_DEPTH_TEST );
    
    glClearColor( 0.0, 0.0, 0.0, 1.0 );
}

void
display( void )
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    for(int i = 0; i < 8; i++){

        glBindVertexArray( vaoArray[i] );

        if((find(begin(aboveFace), end(aboveFace), i) != end(aboveFace))){ 
            
            if(((int)FaceAxisPositioningCCW[Yaxis] % 90 == 0) && FaceBoolY){
                
                if(i == findMaxArr(aboveFace)){                   
                    
                    alignFaceTemp();                    
                    
                    aboveFace[0] = aboveFaceTemp[2];
                    aboveFace[1] = aboveFaceTemp[0];
                    aboveFace[2] = aboveFaceTemp[3];
                    aboveFace[3] = aboveFaceTemp[1];
                    
                    rightFace[0] = frontFaceTemp[0];
                    rightFace[2] = frontFaceTemp[1];

                    leftFace[0] = behindFaceTemp[0];
                    leftFace[2] = behindFaceTemp[1];

                    frontFace[0] = leftFaceTemp[2];
                    frontFace[1] = leftFaceTemp[0];
                    
                    behindFace[0] = rightFaceTemp[2];
                    behindFace[1] = rightFaceTemp[0];
                                        
                    FaceBoolY = false;
                    keyAnyPressed = false;                    
                }
            }
            
            if(keyFivePressed){
                ModelViews[i] =  RotateY( initialAxisPositioning[Yaxis] ) * RotateX( initialAxisPositioning[Xaxis] ) * RotateY( 1.0 ) * RotateX( -initialAxisPositioning[Xaxis] ) * RotateY( -initialAxisPositioning[Yaxis] ) * ModelViews[i];
            }
            
            
            if(((int)FaceAxisPositioningCW[Yaxis] % 90 == 0) && FaceViewBoolY){
                
                if(i == findMaxArr(aboveFace)){ 
                    
                    alignFaceTemp();
                    
                    aboveFace[0] = aboveFaceTemp[1];
                    aboveFace[1] = aboveFaceTemp[3];
                    aboveFace[2] = aboveFaceTemp[0];
                    aboveFace[3] = aboveFaceTemp[2];
                    
                    rightFace[0] = behindFaceTemp[1];
                    rightFace[2] = behindFaceTemp[0];
                    
                    leftFace[0] = frontFaceTemp[1];
                    leftFace[2] = frontFaceTemp[0];
                    
                    frontFace[0] = rightFaceTemp[0];
                    frontFace[1] = rightFaceTemp[2];
                    
                    behindFace[0] = leftFaceTemp[0];
                    behindFace[1] = leftFaceTemp[2];                    
                    
                    FaceViewBoolY = false;
                    keyAnyPressed = false;                    
                }
            }
            
            if(keySixPressed){
                ModelViews[i] =  RotateY( initialAxisPositioning[Yaxis] ) * RotateX( initialAxisPositioning[Xaxis] ) * RotateY( -1.0 ) * RotateX( -initialAxisPositioning[Xaxis] ) * RotateY( -initialAxisPositioning[Yaxis] ) * ModelViews[i];
            }
            
        }

        if((find(begin(rightFace), end(rightFace), i) != end(rightFace))){ 

            if(((int)FaceAxisPositioningCCW[Xaxis] % 90 == 0) && FaceBoolX){
                
                if(i == findMaxArr(rightFace)){
                    
                    alignFaceTemp();               
                                            
                    rightFace[0] = rightFaceTemp[2];
                    rightFace[1] = rightFaceTemp[0];
                    rightFace[2] = rightFaceTemp[3];
                    rightFace[3] = rightFaceTemp[1];

                    frontFace[1] = aboveFaceTemp[3];
                    frontFace[3] = aboveFaceTemp[1];

                    behindFace[1] = belowFaceTemp[3];
                    behindFace[3] = belowFaceTemp[1];  

                    aboveFace[1] = behindFaceTemp[1];
                    aboveFace[3] = behindFaceTemp[3];     

                    belowFace[1] = frontFaceTemp[1];     
                    belowFace[3] = frontFaceTemp[3];       
                    
                    FaceBoolX = false;
                    keyAnyPressed = false;                    
                }
            }
            
            if(keyOnePressed){
                ModelViews[i] =  RotateY( initialAxisPositioning[Yaxis] ) * RotateX( initialAxisPositioning[Xaxis] ) * RotateX( 1.0 ) * RotateX( -initialAxisPositioning[Xaxis] ) * RotateY( -initialAxisPositioning[Yaxis] ) * ModelViews[i];
            }
            
            if(((int)FaceAxisPositioningCW[Xaxis] % 90 == 0) && FaceViewBoolX){
                
                if(i == findMaxArr(rightFace)){
                    
                    alignFaceTemp();
                    
                    rightFace[0] = rightFaceTemp[1];
                    rightFace[1] = rightFaceTemp[3];
                    rightFace[2] = rightFaceTemp[0];
                    rightFace[3] = rightFaceTemp[2];
                    
                    frontFace[1] = belowFaceTemp[1];
                    frontFace[3] = belowFaceTemp[3];
                    
                    behindFace[1] = aboveFaceTemp[1];
                    behindFace[3] = aboveFaceTemp[3];
                    
                    aboveFace[1] = frontFaceTemp[3];
                    aboveFace[3] = frontFaceTemp[1];
                    
                    belowFace[1] = behindFaceTemp[3];
                    belowFace[3] = behindFaceTemp[1];
                    
                    FaceViewBoolX = false;
                    keyAnyPressed = false;                    
                }
            }
            
            if(keyTwoPressed){
                ModelViews[i] =  RotateY( initialAxisPositioning[Yaxis] ) * RotateX( initialAxisPositioning[Xaxis] ) * RotateX( -1.0 ) * RotateX( -initialAxisPositioning[Xaxis] ) * RotateY( -initialAxisPositioning[Yaxis] ) * ModelViews[i];
            }
        }        
        
        if((find(begin(frontFace), end(frontFace), i) != end(frontFace))){ 
            
            if(((int)FaceAxisPositioningCCW[Zaxis] % 90 == 0) && FaceBoolZ){
                
                if(i == findMaxArr(frontFace)){                     
                    
                    alignFaceTemp();
                    
                    frontFace[0] = frontFaceTemp[1];
                    frontFace[1] = frontFaceTemp[3];
                    frontFace[2] = frontFaceTemp[0];
                    frontFace[3] = frontFaceTemp[2];
                    
                    rightFace[0] = belowFaceTemp[1];
                    rightFace[1] = belowFaceTemp[0];
                    
                    leftFace[0] = aboveFaceTemp[1];
                    leftFace[1] = aboveFaceTemp[0];
                    
                    aboveFace[0] = rightFaceTemp[0];
                    aboveFace[1] = rightFaceTemp[1];
                    
                    belowFace[0] = leftFaceTemp[0];
                    belowFace[1] = leftFaceTemp[1];
                    
                    FaceBoolZ = false;
                    keyAnyPressed = false;                    
                }
            }
            
            if(keyThreePressed){
                ModelViews[i] =  RotateY( initialAxisPositioning[Yaxis] ) * RotateX( initialAxisPositioning[Xaxis] ) * RotateZ( 1.0 ) * RotateX( -initialAxisPositioning[Xaxis] ) * RotateY( -initialAxisPositioning[Yaxis] ) * ModelViews[i];
            }
            
            if(((int)FaceAxisPositioningCW[Zaxis] % 90 == 0) && FaceViewBoolZ){
                
                if(i == findMaxArr(frontFace)){                    
                    
                    alignFaceTemp();
                    
                    frontFace[0] = frontFaceTemp[2];
                    frontFace[1] = frontFaceTemp[0];
                    frontFace[2] = frontFaceTemp[3];
                    frontFace[3] = frontFaceTemp[1];
                    
                    rightFace[0] = aboveFaceTemp[0];
                    rightFace[1] = aboveFaceTemp[1];
                    
                    leftFace[0] = belowFaceTemp[0];
                    leftFace[1] = belowFaceTemp[1];
                    
                    aboveFace[0] = leftFaceTemp[1];
                    aboveFace[1] = leftFaceTemp[0];
                    
                    belowFace[0] = rightFaceTemp[1];
                    belowFace[1] = rightFaceTemp[0];
                    
                    FaceViewBoolZ = false;
                    keyAnyPressed = false;                    
                }
            }
            
            if(keyFourPressed){
                ModelViews[i] =  RotateY( initialAxisPositioning[Yaxis] ) * RotateX( initialAxisPositioning[Xaxis] ) * RotateZ( -1.0 ) * RotateX( -initialAxisPositioning[Xaxis] ) * RotateY( -initialAxisPositioning[Yaxis] ) * ModelViews[i];
            }
        }      
        
        if((int)ViewAxisPositioningCCW[Yaxis] % 90 == 0 && ViewBoolYCCW){
            
            if(i == 7){ 
                
                alignFaceTemp();
                
                rightFace[0] = frontFaceTemp[0];
                rightFace[1] = frontFaceTemp[2];
                rightFace[2] = frontFaceTemp[1];
                rightFace[3] = frontFaceTemp[3];
                
                leftFace[0] = behindFaceTemp[0];
                leftFace[1] = behindFaceTemp[2];
                leftFace[2] = behindFaceTemp[1];
                leftFace[3] = behindFaceTemp[3];
                
                frontFace[0] = leftFaceTemp[2];
                frontFace[1] = leftFaceTemp[0];
                frontFace[2] = leftFaceTemp[3];
                frontFace[3] = leftFaceTemp[1];
                
                behindFace[0] = rightFaceTemp[2];
                behindFace[1] = rightFaceTemp[0];
                behindFace[2] = rightFaceTemp[3];
                behindFace[3] = rightFaceTemp[1];
                
                aboveFace[0] = aboveFaceTemp[2];
                aboveFace[1] = aboveFaceTemp[0];
                aboveFace[2] = aboveFaceTemp[3];
                aboveFace[3] = aboveFaceTemp[1];
                
                belowFace[0] = belowFaceTemp[2];
                belowFace[1] = belowFaceTemp[0];
                belowFace[2] = belowFaceTemp[3];
                belowFace[3] = belowFaceTemp[1];
                
                ViewBoolYCCW = false;
                keyAnyPressed = false;
            
            }
            
        }
        
        if(keyRightPressed){
           
            ModelViews[i] = RotateY( initialAxisPositioning[Yaxis] ) * RotateX( initialAxisPositioning[Xaxis] ) * RotateY( 1.0 ) * RotateX( -initialAxisPositioning[Xaxis] ) * RotateY( -initialAxisPositioning[Yaxis] ) *  ModelViews[i];
            
        }
                
        if((int)ViewAxisPositioningCCW[Xaxis] % 90 == 0 && ViewBoolXCCW){
            
            if(i == 7){
                
                alignFaceTemp();
                
                rightFace[0] = rightFaceTemp[2];
                rightFace[1] = rightFaceTemp[0];
                rightFace[2] = rightFaceTemp[3];
                rightFace[3] = rightFaceTemp[1];
                
                leftFace[0] = leftFaceTemp[2];
                leftFace[1] = leftFaceTemp[0];
                leftFace[2] = leftFaceTemp[3];
                leftFace[3] = leftFaceTemp[1];
                
                frontFace[0] = aboveFaceTemp[2];
                frontFace[1] = aboveFaceTemp[3];
                frontFace[2] = aboveFaceTemp[0];
                frontFace[3] = aboveFaceTemp[1];
                
                behindFace[0] = belowFaceTemp[2];
                behindFace[1] = belowFaceTemp[3];
                behindFace[2] = belowFaceTemp[0];
                behindFace[3] = belowFaceTemp[1];
                
                aboveFace[0] = behindFaceTemp[0];
                aboveFace[1] = behindFaceTemp[1];
                aboveFace[2] = behindFaceTemp[2];
                aboveFace[3] = behindFaceTemp[3];
                
                belowFace[0] = frontFaceTemp[0];
                belowFace[1] = frontFaceTemp[1];
                belowFace[2] = frontFaceTemp[2];
                belowFace[3] = frontFaceTemp[3];
                
                ViewBoolXCCW = false;
                keyAnyPressed = false;
                
            }
            
        }
                
        if(keyDownPressed){
            ModelViews[i] = RotateY( initialAxisPositioning[Yaxis] ) * RotateX( initialAxisPositioning[Xaxis] ) * RotateX( 1.0 ) * RotateX( -initialAxisPositioning[Xaxis] ) * RotateY( -initialAxisPositioning[Yaxis] ) *  ModelViews[i];
        }
                
        if((int)ViewAxisPositioningCW[Yaxis] % 90 == 0 && ViewBoolYCW){
            
            if(i == 7){ 
                
                alignFaceTemp();
                
                rightFace[0] = behindFaceTemp[1];
                rightFace[1] = behindFaceTemp[3];
                rightFace[2] = behindFaceTemp[0];
                rightFace[3] = behindFaceTemp[2];
                
                leftFace[0] = frontFaceTemp[1];
                leftFace[1] = frontFaceTemp[3];
                leftFace[2] = frontFaceTemp[0];
                leftFace[3] = frontFaceTemp[2];
                
                frontFace[0] = rightFaceTemp[0];
                frontFace[1] = rightFaceTemp[2];
                frontFace[2] = rightFaceTemp[1];
                frontFace[3] = rightFaceTemp[3];

                behindFace[0] = leftFaceTemp[0];
                behindFace[1] = leftFaceTemp[2];
                behindFace[2] = leftFaceTemp[1];
                behindFace[3] = leftFaceTemp[3];
                
                aboveFace[0] = aboveFaceTemp[1];
                aboveFace[1] = aboveFaceTemp[3];
                aboveFace[2] = aboveFaceTemp[0];
                aboveFace[3] = aboveFaceTemp[2];
                
                belowFace[0] = belowFaceTemp[1];
                belowFace[1] = belowFaceTemp[3];
                belowFace[2] = belowFaceTemp[0];
                belowFace[3] = belowFaceTemp[2];
                
                ViewBoolYCW = false;
                keyAnyPressed = false;
                
            }
            
        }
        
        if(keyLeftPressed){
            ModelViews[i] = RotateY( initialAxisPositioning[Yaxis] ) * RotateX( initialAxisPositioning[Xaxis] ) * RotateY( -1.0 ) * RotateX( -initialAxisPositioning[Xaxis] ) * RotateY( -initialAxisPositioning[Yaxis] ) *  ModelViews[i];
        }
                
        if((int)ViewAxisPositioningCW[Xaxis] % 90 == 0 && ViewBoolXCW){
            
            if(i == 7){ 
                
                alignFaceTemp();
                
                rightFace[0] = rightFaceTemp[1];
                rightFace[1] = rightFaceTemp[3];
                rightFace[2] = rightFaceTemp[2];
                rightFace[3] = rightFaceTemp[0];
                
                leftFace[0] = leftFaceTemp[1];
                leftFace[1] = leftFaceTemp[3];
                leftFace[2] = leftFaceTemp[0];
                leftFace[3] = leftFaceTemp[2];
                
                frontFace[0] = belowFaceTemp[0];
                frontFace[1] = belowFaceTemp[1];
                frontFace[2] = belowFaceTemp[2];
                frontFace[3] = belowFaceTemp[3];
                                
                behindFace[0] = aboveFaceTemp[0];
                behindFace[1] = aboveFaceTemp[1];
                behindFace[2] = aboveFaceTemp[2];
                behindFace[3] = aboveFaceTemp[3];
                
                aboveFace[0] = frontFaceTemp[2];
                aboveFace[1] = frontFaceTemp[3];
                aboveFace[2] = frontFaceTemp[0];
                aboveFace[3] = frontFaceTemp[1];
                
                belowFace[0] = behindFaceTemp[2];
                belowFace[1] = behindFaceTemp[3];
                belowFace[2] = behindFaceTemp[0];
                belowFace[3] = behindFaceTemp[1];
                
                ViewBoolXCW = false;
                keyAnyPressed = false;
                
            }
            
        }
        
        if(keyUpPressed){ 
            ModelViews[i] = RotateY( initialAxisPositioning[Yaxis] ) * RotateX( initialAxisPositioning[Xaxis] ) * RotateX( -1.0 ) * RotateX( -initialAxisPositioning[Xaxis] ) * RotateY( -initialAxisPositioning[Yaxis] ) *  ModelViews[i];
        }
        
        glUniformMatrix4fv( ModelView, 1, GL_TRUE, ModelViews[i] );
        
        glDrawArrays( GL_TRIANGLES, 0, NumVertices );
        
    }
    
    mat4  projection;
    projection = Ortho(-2.0, 2.0, -2.0, 2.0, -2.0, 2.0); 
    glUniformMatrix4fv( Projection, 1, GL_TRUE, projection );
    
    glutSwapBuffers();
    
}

void
idle( void )
{    
    if(keyLeftPressed && ((int)ViewAxisPositioningCW[Yaxis] % 90 != 0)){
        ViewBoolYCW = true;
        ViewAxisPositioningCW[Yaxis] -= 1.0;
        
        if (ViewAxisPositioningCW[Yaxis] <= -360.0) {
            ViewAxisPositioningCW[Yaxis] += 360.0;
        }        
        if(((int)ViewAxisPositioningCW[Yaxis] % 90 == 0)){
            keyLeftPressed = false;
            ViewBoolYCW = true;
        }
    }
    
    if(keyRightPressed && ((int)ViewAxisPositioningCCW[Yaxis] % 90 != 0)){
        ViewBoolYCCW = true;
        ViewAxisPositioningCCW[Yaxis] += 1.0;
        
        if ( ViewAxisPositioningCCW[Yaxis] >= 360.0 ) {
            ViewAxisPositioningCCW[Yaxis] -= 360.0;
        }        
        if(((int)ViewAxisPositioningCCW[Yaxis] % 90 == 0)){
            
            keyRightPressed = false;
            ViewBoolYCCW = true;
        }
        
    }

    if(keyDownPressed && ((int)ViewAxisPositioningCCW[Xaxis] % 90 != 0)){
        ViewBoolXCCW = true;
        ViewAxisPositioningCCW[Xaxis] += 1.0;
        
        if ( ViewAxisPositioningCCW[Xaxis] >= 360.0 ) {
            ViewAxisPositioningCCW[Xaxis] -= 360.0;
        }        
        if(((int)ViewAxisPositioningCCW[Xaxis] % 90 == 0)){
            keyDownPressed = false;
            ViewBoolXCCW = true;
        }
        
    }    
    
    if(keyUpPressed && ((int)ViewAxisPositioningCW[Xaxis] % 90 != 0)){
        ViewBoolXCW = true;
        ViewAxisPositioningCW[Xaxis] -= 1.0;
        
        if ( ViewAxisPositioningCW[Xaxis] <= -360.0 ) {
            ViewAxisPositioningCW[Xaxis] += 360.0;
        }        
        if(((int)ViewAxisPositioningCW[Xaxis] % 90 == 0)){
            keyUpPressed = false;
            ViewBoolXCW = true;
        }
        
    }
    
    if(keyOnePressed && ((int)FaceAxisPositioningCCW[Xaxis] % 90 != 0)){
        FaceBoolX = true;
        FaceAxisPositioningCCW[Xaxis] += 1.0;
        
        if ( FaceAxisPositioningCCW[Xaxis] >= 360.0 ) {
            FaceAxisPositioningCCW[Xaxis] -= 360.0;
        }        
        if(((int)FaceAxisPositioningCCW[Xaxis] % 90 == 0)){
            keyOnePressed = false;
            FaceBoolX = true;
        }
    }
    
    if(keyTwoPressed && ((int)FaceAxisPositioningCW[Xaxis] % 90 != 0)){
        FaceViewBoolX = true;
        FaceAxisPositioningCW[Xaxis] -= 1.0;
        
        if ( FaceAxisPositioningCW[Xaxis] <= 360.0 ) {
            FaceAxisPositioningCW[Xaxis] += 360.0;
        }        
        if(((int)FaceAxisPositioningCW[Xaxis] % 90 == 0)){
            keyTwoPressed = false;
            FaceViewBoolX = true;
        }
    }    
    
    if(keyThreePressed && ((int)FaceAxisPositioningCCW[Zaxis] % 90 != 0)){
        FaceBoolZ = true;
        FaceAxisPositioningCCW[Zaxis] += 1.0;
        
        if ( FaceAxisPositioningCCW[Zaxis] >= 360.0 ) {
            FaceAxisPositioningCCW[Zaxis] -= 360.0;
        }        
        if(((int)FaceAxisPositioningCCW[Zaxis] % 90 == 0)){
            keyThreePressed = false;
            FaceBoolZ = true;
        }
    }
    
    if(keyFourPressed && ((int)FaceAxisPositioningCW[Zaxis] % 90 != 0)){
        FaceViewBoolZ = true;
        FaceAxisPositioningCW[Zaxis] -= 1.0;
        
        if ( FaceAxisPositioningCW[Zaxis] <= -360.0 ) {
            FaceAxisPositioningCW[Zaxis] += 360.0;
        }        
        if(((int)FaceAxisPositioningCW[Zaxis] % 90 == 0)){
            keyFourPressed = false;
            FaceViewBoolZ = true;
        }
    }
    
    if(keyFivePressed && ((int)FaceAxisPositioningCCW[Yaxis] % 90 != 0)){
        FaceBoolY = true;
        FaceAxisPositioningCCW[Yaxis] += 1.0;
        
        if ( FaceAxisPositioningCCW[Yaxis] >= 360.0 ) {
            FaceAxisPositioningCCW[Yaxis] -= 360.0;
        }        
        if(((int)FaceAxisPositioningCCW[Yaxis] % 90 == 0)){
            keyFivePressed = false;
            FaceBoolY = true;
        }
    }
    
    if(keySixPressed && ((int)FaceAxisPositioningCW[Yaxis] % 90 != 0)){
        FaceViewBoolY = true;
        FaceAxisPositioningCW[Yaxis] -= 1.0;
        
        if ( FaceAxisPositioningCW[Yaxis] <= -360.0 ) {
            FaceAxisPositioningCW[Yaxis] += 360.0;
        }        
        if(((int)FaceAxisPositioningCW[Yaxis] % 90 == 0)){
            keySixPressed = false;
            FaceViewBoolY = true;
        }
    } 
    
    glutPostRedisplay();
}

void
keyboard( unsigned char key,int x, int y )
{
    if(key == 'Q' | key == 'q')
        exit(0);
    else if(key == '1'){
        
        if(!keyAnyPressed){
            keyAnyPressed = true;
            FaceAxisPositioningCCW[Xaxis] += 1.0;
            keyOnePressed = true;
        }
        
    }
    else if(key == '2'){
        
        if(!keyAnyPressed){
            keyAnyPressed = true;
            FaceAxisPositioningCW[Xaxis] -= 1.0;
            keyTwoPressed = true;
        }
        
    }
    else if(key == '3'){
        
        if(!keyAnyPressed){
            keyAnyPressed = true;
            FaceAxisPositioningCCW[Zaxis] += 1.0;
            keyThreePressed = true;
        }
        
    }
    else if(key == '4'){ 
        
        if(!keyAnyPressed){
            keyAnyPressed = true;
            FaceAxisPositioningCW[Zaxis] -= 1.0;
            keyFourPressed = true;
        }
        
    }
    else if(key == '5'){
        
        if(!keyAnyPressed){
            keyAnyPressed = true;
            FaceAxisPositioningCCW[Yaxis] += 1.0;
            keyFivePressed = true;
        }
        
    }
    else if(key == '6'){
        
        if(!keyAnyPressed){
            keyAnyPressed = true;
            FaceAxisPositioningCW[Yaxis] -= 1.0;
            keySixPressed = true;
        }
        
    }
    else if(key == 'H' | key == 'h'){
        cout << "\nKey\tFunction\n" << endl;
        cout << "Q\tQuit" << endl;
        cout << "H\tHelp" << endl;
        cout << "Left Arrow\tRotate the Cube around Y Axis clockwise" << endl;
        cout << "Right Arrow\tRotate the Cube around Y Axis counter clockwise" << endl;
        cout << "Up Arrow\tRotate the Cube around X Axis clockwise" << endl;
        cout << "Down Arrow\tRotate the Cube around X Axis counter clockwise" << endl;
        cout << "1\tTransform the Cube's right face counter clockwise" << endl;
        cout << "2\tTransform the Cube's right face clockwise" << endl;
        cout << "3\tTransform the Cube's front face counter clockwise" << endl;
        cout << "4\tTransform the Cube's front face clockwise" << endl;
        cout << "5\tTransform the Cube's above face counter clockwise" << endl;
        cout << "6\tTransform the Cube's above face clockwise" << endl;
        
    }
    
}

void
catchKey(int key, int x, int y)
{
    if(key == GLUT_KEY_LEFT)    
        { 
        
        if(!keyAnyPressed){
            keyAnyPressed = true;
            keyLeftPressed = true;
            ViewAxisPositioningCW[Yaxis] -= 1.0;
        }
        
    }
    else if(key == GLUT_KEY_RIGHT){ 
        
        if(!keyAnyPressed){
            keyAnyPressed = true;
            keyRightPressed = true;
            ViewAxisPositioningCCW[Yaxis] += 1.0;
        }
    }
    else if(key == GLUT_KEY_DOWN){ 
        
        if(!keyAnyPressed){
            keyAnyPressed = true;
            keyDownPressed = true;
            ViewAxisPositioningCCW[Xaxis] += 1.0;
        }
    }
    else if(key == GLUT_KEY_UP){ 
        
        if(!keyAnyPressed){
            keyAnyPressed = true;
            keyUpPressed = true;
            ViewAxisPositioningCW[Xaxis] -= 1.0;
        }
    }
}
int numSteps = 0;
bool boolRand = true;

void randomInit( int p )
{
    if(boolRand){
        int randNum = rand() % 4;

        if(numSteps == 10)
            boolRand = false;    
                        
        if(randNum == 0){
            if(!keyAnyPressed){ 
                keyAnyPressed = true;
                ViewAxisPositioningCCW[Yaxis] += 1.0;
                keyRightPressed = true;
            }
        }
        else if(randNum == 1){
            if(!keyAnyPressed){
                keyAnyPressed = true;
                FaceAxisPositioningCCW[Xaxis] += 1.0;
                keyOnePressed = true;
            }
        }
        else if(randNum == 2){
            if(!keyAnyPressed){ 
                keyAnyPressed = true;
                FaceAxisPositioningCCW[Zaxis] += 1.0;
                keyThreePressed = true;
            }
        }
        else{
            if(!keyAnyPressed){ 
                keyAnyPressed = true;
                FaceAxisPositioningCCW[Yaxis] += 1.0;
                keyFivePressed = true;
            }
        }
        numSteps++;
    }
    
    glutTimerFunc(300, randomInit, 0);
}

void 
reshape( int w, int h )
{
    glViewport( 0, 0, w, h );
    
    mat4  projection;
    if (w <= h)
        projection = Ortho(-1.0, 1.0, -1.0 * (GLfloat) h / (GLfloat) w,
                           1.0 * (GLfloat) h / (GLfloat) w, -1.0, 1.0);
    else  projection = Ortho(-1.0* (GLfloat) w / (GLfloat) h, 1.0 *
                             (GLfloat) w / (GLfloat) h, -1.0, 1.0, -1.0, 1.0);
    glUniformMatrix4fv( Projection, 1, GL_TRUE, projection );
    
}

int
main( int argc, char **argv )
{
    glutInit( &argc, argv );
    glutInitDisplayMode(  GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH );
    glutInitWindowSize( 512, 512 );
    
    glutCreateWindow("0049826 - COMP410 HW#2");

	glewExperimental = GL_TRUE;
    glewInit();
    
    init();
    
    glutDisplayFunc(display); 
    glutReshapeFunc(reshape);
    glutIdleFunc(idle);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(catchKey);
    glutTimerFunc(3, randomInit, 0);
    
    glutMainLoop();   
    
    cout << "Press H for help" << endl;
    return 0;
}