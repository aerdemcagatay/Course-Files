clear
close all

load('seq.mat')

T_single = [1];
E_single = [rand() rand()];
E_single = E_single / sum(E_single);


T_two = [rand() rand(); rand() rand()];
T_two(1,:) = T_two(1,:) / sum(T_two(1,:));
T_two(2,:) = T_two(2,:) / sum(T_two(2,:));

E_two = [rand() rand(); rand() rand()];
E_two(1,:) = E_two(1,:) / sum(E_two(1,:));
E_two(2,:) = E_two(2,:) / sum(E_two(2,:));

T_three = [rand() rand() rand(); rand() rand() rand(); rand() rand() rand()];
T_three(1,:) = T_three(1,:) / sum(T_three(1,:));
T_three(2,:) = T_three(2,:) / sum(T_three(2,:));
T_three(3,:) = T_three(3,:) / sum(T_three(3,:));

E_three = [rand() rand(); rand() rand(); rand() rand()];
E_three(1,:) = E_three(1,:) / sum(E_three(1,:));
E_three(2,:) = E_three(2,:) / sum(E_three(2,:));
E_three(3,:) = E_three(3,:) / sum(E_three(3,:));

[T1, E1] = hmmtrain(seq, T_single, E_single);
[T2, E2] = hmmtrain(seq, T_two, E_two);
[T3, E3] = hmmtrain(seq, T_three, E_three);