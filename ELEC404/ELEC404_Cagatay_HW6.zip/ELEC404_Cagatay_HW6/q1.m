clear
close all

%transition and emission matrices
T = [0.7 0.3; 0.3 0.7];
E=[0.8 0.2; 0.3 0.7];

length = 10000;

[seq, stt] = hmmgenerate(length, T, E);

stt_likely = hmmviterbi(seq, T, E);
stt_correct_rate = sum(stt == stt_likely) / length;

T2=[0.9 0.1 ; 0.1 0.9];
E2=[0.1 0.9 ; 0.1 0.9];

[T_EST, E_EST] = hmmtrain(seq, T2, E2);