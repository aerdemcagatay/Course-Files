clear
close all

[soundfile, Fs] = audioread('sx229.wav');

%IIR Lowpass Filters%
fs = 16000;

%Cutoff frequency 4000 Hz%
fc = 4000;
fcnormal = 2*fc/fs;

%Order 5%
n = 5;
[b,a] = ellip(n,5,40,fcnormal);
figure
freqz(b,a)
title('IIR Lowpass Filter - Cutoff frequency 4000 Hz - Order 5');

pause(1);
filtered_soundfile = filter(b, 1, soundfile);
soundsc(filtered_soundfile, Fs);

%Order 10%
n = 10;
[b,a] = ellip(n,5,40,fcnormal);
figure
freqz(b,a)
title('IIR Lowpass Filter - Cutoff frequency 4000 Hz - Order 10');

pause(1);
filtered_soundfile = filter(b, 1, soundfile);
soundsc(filtered_soundfile, Fs);

%Cutoff frequency 2000 Hz%
fc = 2000;
fcnormal = 2*fc/fs;

%Order 5%
n = 5;
[b,a] = ellip(n,5,40,fcnormal);
figure
freqz(b,a)
title('IIR Lowpass Filter - Cutoff frequency 2000 Hz - Order 5');

pause(1);
filtered_soundfile = filter(b, 1, soundfile);
soundsc(filtered_soundfile, Fs);

%Order 10%
n = 10;
[b,a] = ellip(n,5,40,fcnormal);
figure
freqz(b,a)
title('IIR Lowpass Filter - Cutoff frequency 2000 Hz - Order 10');

pause(1);
filtered_soundfile = filter(b, 1, soundfile);
soundsc(filtered_soundfile, Fs);

%Cutoff frequency 1000 Hz%
fc = 1000;
fcnormal = 2*fc/fs;

%Order 5%
n = 5;
[b,a] = ellip(n,5,40,fcnormal);
figure
freqz(b,a)
title('IIR Lowpass Filter - Cutoff frequency 1000 Hz - Order 5');

pause(1);
filtered_soundfile = filter(b, 1, soundfile);
soundsc(filtered_soundfile, Fs);

%Order 10%
n = 10;
[b,a] = ellip(n,5,40,fcnormal);
figure
freqz(b,a)
title('IIR Lowpass Filter - Cutoff frequency 1000 Hz - Order 10');

pause(1);
filtered_soundfile = filter(b, 1, soundfile);
soundsc(filtered_soundfile, Fs);