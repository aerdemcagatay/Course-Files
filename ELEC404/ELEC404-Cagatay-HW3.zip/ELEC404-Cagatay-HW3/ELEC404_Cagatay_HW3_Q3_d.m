clear
close all

[soundfile, Fs] = audioread('sx229.wav');

fs = 16000;

%FIR Lowpass Filters%

%Cutoff Frequency 4000 Hz%
fc = 4000;
fcnormal = 2*fc/fs;

f = [0; (fcnormal-0.05); fcnormal; 1];
a = [1; 1; 0; 0];

%Order 200%
n = 200;

b = firpm(n,f,a);

[m,n]=size(soundfile);
dt=1/Fs;
t=dt*(0:m-1);
idt = t < 0.45;
filtered_soundfile = soundfile(idt);

pause(1);
filtered_soundfile = filter(b, 1, filtered_soundfile);
soundsc(filtered_soundfile, Fs);

%Cutoff Frequency 2000 Hz%
fc = 2000;
fcnormal = 2*fc/fs;

f = [0; (fcnormal-0.05); fcnormal; 1];
a = [1; 1; 0; 0];

%Order 200%
n = 200;

b = firpm(n,f,a);

[m,n]=size(soundfile);
dt=1/Fs;
t=dt*(0:m-1);
idt = (t >= 0.45) & (t < 0.9);
filtered_soundfile = soundfile(idt);

pause(1);
filtered_soundfile = filter(b, 1, filtered_soundfile);
soundsc(filtered_soundfile, Fs);

%Cutoff Frequency 1000 Hz%
fc = 1000;
fcnormal = 2*fc/fs;

f = [0; (fcnormal-0.05); fcnormal; 1];
a = [1; 1; 0; 0];

%Order 200%
n = 200;

b = firpm(n,f,a);

[m,n]=size(soundfile);
dt=1/Fs;
t=dt*(0:m-1);
idt = (t >= 0.9) & (t < 1.36);
filtered_soundfile = soundfile(idt);

pause(1);
filtered_soundfile = filter(b, 1, filtered_soundfile);
soundsc(filtered_soundfile, Fs);

%IIR Lowpass Filters%

%Cutoff frequency 4000 Hz%
fc = 4000;
fcnormal = 2*fc/fs;

%Order 10%
n = 10;
[b,a] = ellip(n,5,40,fcnormal);

[m,n]=size(soundfile);
dt=1/Fs;
t=dt*(0:m-1);
idt = t < 0.45;
filtered_soundfile = soundfile(idt);

pause(1);
filtered_soundfile = filter(b, 1, filtered_soundfile);
soundsc(filtered_soundfile, Fs);

%Cutoff frequency 2000 Hz%
fc = 2000;
fcnormal = 2*fc/fs;

%Order 10%
n = 10;
[b,a] = ellip(n,5,40,fcnormal);

[m,n]=size(soundfile);
dt=1/Fs;
t=dt*(0:m-1);
idt = (t >= 0.45) & (t < 0.9);
filtered_soundfile = soundfile(idt);

pause(1);
filtered_soundfile = filter(b, 1, filtered_soundfile);
soundsc(filtered_soundfile, Fs);

%Cutoff frequency 1000 Hz%
fc = 1000;
fcnormal = 2*fc/fs;

%Order 10%
n = 10;
[b,a] = ellip(n,5,40,fcnormal);

[m,n]=size(soundfile);
dt=1/Fs;
t=dt*(0:m-1);
idt = (t >= 0.9) & (t < 1.36);
filtered_soundfile = soundfile(idt);

pause(1);
filtered_soundfile = filter(b, 1, filtered_soundfile);
soundsc(filtered_soundfile, Fs);