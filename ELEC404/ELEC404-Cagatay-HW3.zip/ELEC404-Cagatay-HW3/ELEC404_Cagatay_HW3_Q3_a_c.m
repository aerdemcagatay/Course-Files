clear
close all

[soundfile, Fs] = audioread('sx229.wav');

fs = 16000;

%FIR Lowpass Filters%

%Cutoff Frequency 4000 Hz%
fc = 4000;
fcnormal = 2*fc/fs;

f = [0; (fcnormal-0.05); fcnormal; 1];
a = [1; 1; 0; 0];

%Order 10%
n = 10;

b = firpm(n,f,a);
figure
freqz(b,1,512)
title('FIR Lowpass Filter - Cutoff Frequency 4000 Hz - Order 10')

pause(1);
filtered_soundfile = filter(b, 1, soundfile);
soundsc(filtered_soundfile, Fs);

%Order 50%
n = 50;

b = firpm(n,f,a);
figure
freqz(b,1,512)
title('FIR Lowpass Filter - Cutoff Frequency 4000 Hz - Order 50')

pause(1);
filtered_soundfile = filter(b, 1, soundfile);
soundsc(filtered_soundfile, Fs);

%Order 200%
n = 200;

b = firpm(n,f,a);
figure
freqz(b,1,512)
title('FIR Lowpass Filter - Cutoff Frequency 4000 Hz - Order 200')

pause(1);
filtered_soundfile = filter(b, 1, soundfile);
soundsc(filtered_soundfile, Fs);

%Cutoff Frequency 2000 Hz%
fc = 2000;
fcnormal = 2*fc/fs;

f = [0; (fcnormal-0.05); fcnormal; 1];
a = [1; 1; 0; 0];

%Order 10%
n = 10;

b = firpm(n,f,a);
figure
freqz(b,1,512)
title('FIR Lowpass Filter - Cutoff Frequency 2000 Hz - Order 10')

pause(1);
filtered_soundfile = filter(b, 1, soundfile);
soundsc(filtered_soundfile, Fs);

%Order 50%
n = 50;

b = firpm(n,f,a);
figure
freqz(b,1,512)
title('FIR Lowpass Filter - Cutoff Frequency 2000 Hz - Order 50')

pause(1);
filtered_soundfile = filter(b, 1, soundfile);
soundsc(filtered_soundfile, Fs);

%Order 200%
n = 200;

b = firpm(n,f,a);
figure
freqz(b,1,512)
title('FIR Lowpass Filter - Cutoff Frequency 2000 Hz - Order 200')

pause(1);
filtered_soundfile = filter(b, 1, soundfile);
soundsc(filtered_soundfile, Fs);

%Cutoff Frequency 1000 Hz%
fc = 1000;
fcnormal = 2*fc/fs;

f = [0; (fcnormal-0.05); fcnormal; 1];
a = [1; 1; 0; 0];

%Order 10%
n = 10;

b = firpm(n,f,a);
figure
freqz(b,1,512)
title('FIR Lowpass Filter - Cutoff Frequency 1000 Hz - Order 10')

pause(1);
filtered_soundfile = filter(b, 1, soundfile);
soundsc(filtered_soundfile, Fs);

%Order 50%
n = 50;

b = firpm(n,f,a);
figure
freqz(b,1,512)
title('FIR Lowpass Filter - Cutoff Frequency 1000 Hz - Order 50')

pause(1);
filtered_soundfile = filter(b, 1, soundfile);
soundsc(filtered_soundfile, Fs);

%Order 200%
n = 200;

b = firpm(n,f,a);
figure
freqz(b,1,512)
title('FIR Lowpass Filter - Cutoff Frequency 1000 Hz - Order 200')

pause(1);
filtered_soundfile = filter(b, 1, soundfile);
soundsc(filtered_soundfile, Fs);